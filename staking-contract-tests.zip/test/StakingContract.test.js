const { expect } = require("chai")
const { ethers } = require("hardhat")
const { time } = require("@nomicfoundation/hardhat-network-helpers")

describe("StakingContract", () => {
  let stakingContract
  let mockToken
  let owner
  let user1
  let user2
  let merchant

  const toWei = (value) => ethers.utils.parseEther(value.toString())
  const fromWei = (value) => ethers.utils.formatEther(value)

  beforeEach(async () => {
    // Obtener cuentas de prueba
    ;[owner, user1, user2, merchant] = await ethers.getSigners()

    // Desplegar el token ERC20 de prueba
    const MockERC20 = await ethers.getContractFactory("MockERC20")
    mockToken = await MockERC20.deploy()
    await mockToken.deployed()

    // Desplegar el contrato de staking
    const StakingContract = await ethers.getContractFactory("StakingContract")
    stakingContract = await StakingContract.deploy(mockToken.address)
    await stakingContract.deployed()

    // Transferir tokens a los usuarios para las pruebas
    await mockToken.transfer(user1.address, toWei(10000))
    await mockToken.transfer(user2.address, toWei(10000))

    // Aprobar el contrato de staking para gastar tokens
    await mockToken.connect(user1).approve(stakingContract.address, toWei(10000))
    await mockToken.connect(user2).approve(stakingContract.address, toWei(10000))
  })

  describe("Deployment", () => {
    it("Debería establecer el token correcto", async () => {
      expect(await stakingContract.stakingToken()).to.equal(mockToken.address)
    })

    it("Debería establecer el owner correcto", async () => {
      expect(await stakingContract.owner()).to.equal(owner.address)
    })

    it("Debería establecer la tasa de recompensa inicial", async () => {
      expect(await stakingContract.rewardRate()).to.equal(ethers.BigNumber.from("10000000000000"))
    })
  })

  describe("Staking", () => {
    it("Debería permitir hacer staking de tokens", async () => {
      const stakeAmount = toWei(100)

      await expect(stakingContract.connect(user1).stake(stakeAmount))
        .to.emit(stakingContract, "Staked")
        .withArgs(user1.address, stakeAmount)

      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.amount).to.equal(stakeAmount)
    })

    it("Debería fallar al hacer staking de 0 tokens", async () => {
      await expect(stakingContract.connect(user1).stake(0)).to.be.revertedWith("Cannot stake 0 tokens")
    })

    it("Debería fallar si no hay suficiente aprobación", async () => {
      // Revocar la aprobación
      await mockToken.connect(user1).approve(stakingContract.address, 0)

      await expect(stakingContract.connect(user1).stake(toWei(100))).to.be.revertedWith("Transfer failed")
    })

    it("Debería actualizar correctamente el saldo después de múltiples stakes", async () => {
      await stakingContract.connect(user1).stake(toWei(100))
      await stakingContract.connect(user1).stake(toWei(50))

      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.amount).to.equal(toWei(150))
    })
  })

  describe("Unstaking", () => {
    beforeEach(async () => {
      // Hacer staking antes de las pruebas de unstaking
      await stakingContract.connect(user1).stake(toWei(100))
    })

    it("Debería permitir retirar tokens stakeados", async () => {
      const unstakeAmount = toWei(50)

      await expect(stakingContract.connect(user1).unstake(unstakeAmount))
        .to.emit(stakingContract, "Unstaked")
        .withArgs(user1.address, unstakeAmount)

      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.amount).to.equal(toWei(50))
    })

    it("Debería fallar al retirar 0 tokens", async () => {
      await expect(stakingContract.connect(user1).unstake(0)).to.be.revertedWith("Cannot unstake 0 tokens")
    })

    it("Debería fallar si no hay suficientes tokens stakeados", async () => {
      await expect(stakingContract.connect(user1).unstake(toWei(200))).to.be.revertedWith("Insufficient staked amount")
    })

    it("Debería permitir retirar todos los tokens stakeados", async () => {
      await stakingContract.connect(user1).unstake(toWei(100))

      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.amount).to.equal(0)
    })
  })

  describe("Rewards", () => {
    beforeEach(async () => {
      // Hacer staking antes de las pruebas de recompensas
      await stakingContract.connect(user1).stake(toWei(100))
    })

    it("Debería calcular correctamente las recompensas pendientes", async () => {
      // Avanzar el tiempo en 1 día
      await time.increase(86400)

      const reward = await stakingContract.calculatePendingRewards(user1.address)

      // Recompensa esperada: 100 tokens * 86400 segundos * 1e13 / 1e18 = 0.0864 tokens
      // Permitimos un pequeño margen de error debido a la precisión del tiempo
      expect(Number(fromWei(reward))).to.be.closeTo(0.0864, 0.001)
    })

    it("Debería permitir reclamar recompensas", async () => {
      // Avanzar el tiempo en 1 día
      await time.increase(86400)

      const rewardBefore = await stakingContract.calculatePendingRewards(user1.address)

      await expect(stakingContract.connect(user1).claimRewards())
        .to.emit(stakingContract, "RewardPaid")
        .withArgs(user1.address, rewardBefore)

      // Después de reclamar, las recompensas pendientes deberían ser 0
      const rewardAfter = await stakingContract.calculatePendingRewards(user1.address)
      expect(rewardAfter).to.equal(0)

      // Las recompensas reclamadas deberían actualizarse
      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.claimedRewards).to.equal(rewardBefore)
    })

    it("Debería fallar al reclamar si no hay recompensas", async () => {
      // Sin avanzar el tiempo, no debería haber recompensas
      await expect(stakingContract.connect(user1).claimRewards()).to.be.revertedWith("No rewards to claim")
    })

    it("Debería acumular recompensas correctamente después de múltiples periodos", async () => {
      // Primer periodo: 1 día
      await time.increase(86400)

      // Reclamar recompensas
      await stakingContract.connect(user1).claimRewards()

      // Segundo periodo: 2 días
      await time.increase(172800)

      const reward = await stakingContract.calculatePendingRewards(user1.address)

      // Recompensa esperada: 100 tokens * 172800 segundos * 1e13 / 1e18 = 0.1728 tokens
      expect(Number(fromWei(reward))).to.be.closeTo(0.1728, 0.001)
    })
  })

  describe("Payment with Staking", () => {
    beforeEach(async () => {
      // Hacer staking antes de las pruebas de pago
      await stakingContract.connect(user1).stake(toWei(100))

      // Avanzar el tiempo para generar algunas recompensas
      await time.increase(86400)
    })

    it("Debería permitir pagar con recompensas", async () => {
      const rewardBefore = await stakingContract.calculatePendingRewards(user1.address)
      const paymentAmount = rewardBefore.div(2) // Pagar la mitad de las recompensas

      await expect(stakingContract.connect(user1).payWithStaking(paymentAmount, merchant.address))
        .to.emit(stakingContract, "PaymentProcessed")
        .withArgs(user1.address, paymentAmount)

      // Verificar que el comerciante recibió los tokens
      const merchantBalance = await mockToken.balanceOf(merchant.address)
      expect(merchantBalance).to.equal(paymentAmount)

      // Las recompensas pendientes deberían reducirse
      const rewardAfter = await stakingContract.calculatePendingRewards(user1.address)
      expect(rewardAfter).to.equal(0) // Las recompensas se reinician después del pago

      // El monto stakeado no debería cambiar
      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.amount).to.equal(toWei(100))
    })

    it("Debería permitir pagar con tokens stakeados cuando las recompensas no son suficientes", async () => {
      const rewardBefore = await stakingContract.calculatePendingRewards(user1.address)
      const paymentAmount = rewardBefore.add(toWei(10)) // Recompensas + 10 tokens stakeados

      await stakingContract.connect(user1).payWithStaking(paymentAmount, merchant.address)

      // Verificar que el comerciante recibió los tokens
      const merchantBalance = await mockToken.balanceOf(merchant.address)
      expect(merchantBalance).to.equal(paymentAmount)

      // El monto stakeado debería reducirse en 10 tokens
      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.amount).to.equal(toWei(90))
    })

    it("Debería fallar si el pago es mayor que las recompensas + tokens stakeados", async () => {
      const rewardBefore = await stakingContract.calculatePendingRewards(user1.address)
      const paymentAmount = rewardBefore.add(toWei(101)) // Más que las recompensas + tokens stakeados

      await expect(stakingContract.connect(user1).payWithStaking(paymentAmount, merchant.address)).to.be.revertedWith(
        "Insufficient balance for payment",
      )
    })

    it("Debería fallar al pagar 0 tokens", async () => {
      await expect(stakingContract.connect(user1).payWithStaking(0, merchant.address)).to.be.revertedWith(
        "Cannot pay 0 tokens",
      )
    })
  })

  describe("Admin Functions", () => {
    it("Debería permitir al owner cambiar la tasa de recompensa", async () => {
      const newRate = ethers.BigNumber.from("20000000000000") // 2e13

      await stakingContract.connect(owner).setRewardRate(newRate)

      expect(await stakingContract.rewardRate()).to.equal(newRate)
    })

    it("Debería fallar si un no-owner intenta cambiar la tasa de recompensa", async () => {
      const newRate = ethers.BigNumber.from("20000000000000") // 2e13

      await expect(stakingContract.connect(user1).setRewardRate(newRate)).to.be.revertedWith(
        "Ownable: caller is not the owner",
      )
    })
  })

  describe("Integration Tests", () => {
    it("Debería manejar correctamente el flujo completo de staking, generación de recompensas, y pago", async () => {
      // 1. Hacer staking
      await stakingContract.connect(user1).stake(toWei(100))

      // 2. Avanzar el tiempo para generar recompensas
      await time.increase(86400) // 1 día

      // 3. Verificar recompensas
      const reward = await stakingContract.calculatePendingRewards(user1.address)
      expect(Number(fromWei(reward))).to.be.closeTo(0.0864, 0.001)

      // 4. Hacer un pago parcial con recompensas
      const paymentAmount1 = reward.div(2)
      await stakingContract.connect(user1).payWithStaking(paymentAmount1, merchant.address)

      // 5. Avanzar más tiempo
      await time.increase(43200) // 12 horas

      // 6. Hacer un pago que use recompensas + tokens stakeados
      const newReward = await stakingContract.calculatePendingRewards(user1.address)
      const paymentAmount2 = newReward.add(toWei(20))
      await stakingContract.connect(user1).payWithStaking(paymentAmount2, merchant.address)

      // 7. Verificar el saldo final de staking
      const stakeInfo = await stakingContract.stakes(user1.address)
      expect(stakeInfo.amount).to.equal(toWei(80))

      // 8. Retirar todos los tokens restantes
      await stakingContract.connect(user1).unstake(toWei(80))

      // 9. Verificar que el saldo de staking es 0
      const finalStakeInfo = await stakingContract.stakes(user1.address)
      expect(finalStakeInfo.amount).to.equal(0)
    })

    it("Debería manejar correctamente múltiples usuarios haciendo staking y reclamando recompensas", async () => {
      // Usuario 1 hace staking
      await stakingContract.connect(user1).stake(toWei(100))

      // Avanzar tiempo
      await time.increase(43200) // 12 horas

      // Usuario 2 hace staking
      await stakingContract.connect(user2).stake(toWei(200))

      // Avanzar más tiempo
      await time.increase(43200) // 12 horas más

      // Verificar recompensas para ambos usuarios
      const reward1 = await stakingContract.calculatePendingRewards(user1.address)
      const reward2 = await stakingContract.calculatePendingRewards(user2.address)

      // Usuario 1 debería tener recompensas por 24 horas
      expect(Number(fromWei(reward1))).to.be.closeTo(0.0864, 0.001)

      // Usuario 2 debería tener recompensas por 12 horas, pero con el doble de tokens
      expect(Number(fromWei(reward2))).to.be.closeTo(0.0864, 0.001)

      // Ambos usuarios reclaman recompensas
      await stakingContract.connect(user1).claimRewards()
      await stakingContract.connect(user2).claimRewards()

      // Verificar que las recompensas se reiniciaron
      const newReward1 = await stakingContract.calculatePendingRewards(user1.address)
      const newReward2 = await stakingContract.calculatePendingRewards(user2.address)

      expect(newReward1).to.equal(0)
      expect(newReward2).to.equal(0)
    })
  })
})
