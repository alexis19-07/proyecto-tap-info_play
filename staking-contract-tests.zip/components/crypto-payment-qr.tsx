"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { QRCodeSVG } from "qrcode.react"
import { Loader2, CheckCircle, AlertCircle, Wallet, LogOut } from "lucide-react"
import {
  connectWallet,
  disconnectWallet,
  payWithCrypto,
  isOrderPaid,
  getPendingRewards,
} from "@/lib/blockchain-service"
import { useCurrency } from "@/lib/currency-context"

interface CryptoPaymentQRProps {
  orderId: string
  amount: number
  onPaymentComplete: () => void
}

export function CryptoPaymentQR({ orderId, amount, onPaymentComplete }: CryptoPaymentQRProps) {
  const { formatPrice, country } = useCurrency()
  const [walletAddress, setWalletAddress] = useState<string | null>(null)
  const [pendingRewards, setPendingRewards] = useState<string>("0")
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "processing" | "success" | "error">("pending")
  const [errorMessage, setErrorMessage] = useState<string>("")
  const [walletDetected, setWalletDetected] = useState<boolean>(false)

  // Generar los datos para el código QR
  const qrData = JSON.stringify({
    action: "pay",
    orderId,
    amount,
    currency: country.currency.code,
    contract: "crypto_payment",
    timestamp: Date.now(),
  })

  // Verificar si MetaMask está instalado
  useEffect(() => {
    const checkWallet = () => {
      if (typeof window !== "undefined" && window.ethereum) {
        setWalletDetected(true)

        // Escuchar cambios de cuenta
        window.ethereum.on("accountsChanged", (accounts: string[]) => {
          if (accounts.length > 0) {
            setWalletAddress(accounts[0])
            updateRewards(accounts[0])
          } else {
            setWalletAddress(null)
            setPendingRewards("0")
          }
        })

        // Escuchar cambios de red
        window.ethereum.on("chainChanged", () => {
          // Recargar la página cuando cambia la red
          window.location.reload()
        })
      }
    }

    checkWallet()

    // Limpiar listeners cuando el componente se desmonta
    return () => {
      if (typeof window !== "undefined" && window.ethereum) {
        window.ethereum.removeAllListeners("accountsChanged")
        window.ethereum.removeAllListeners("chainChanged")
      }
    }
  }, [])

  // Actualizar recompensas para una dirección
  const updateRewards = async (address: string) => {
    try {
      const rewards = await getPendingRewards(address)
      setPendingRewards(rewards)
    } catch (error) {
      console.error("Error al obtener recompensas:", error)
    }
  }

  // Conectar la billetera al cargar el componente
  useEffect(() => {
    const init = async () => {
      try {
        if (!walletDetected) return

        // Verificar si ya hay una cuenta conectada
        if (typeof window !== "undefined" && window.ethereum) {
          const accounts = await window.ethereum.request({ method: "eth_accounts" })
          if (accounts.length > 0) {
            setWalletAddress(accounts[0])
            updateRewards(accounts[0])
          }
        }

        // Verificar si la orden ya ha sido pagada
        const paid = await isOrderPaid(orderId)
        if (paid) {
          setPaymentStatus("success")
        }
      } catch (error) {
        console.error("Error al inicializar:", error)
      }
    }

    init()
  }, [orderId, walletDetected])

  // Función para procesar el pago
  const handleProcessPayment = async () => {
    if (!walletAddress) {
      setErrorMessage("Por favor conecta tu billetera primero")
      return
    }

    setPaymentStatus("processing")
    setErrorMessage("")

    try {
      // Convertir el monto a string para la función payWithCrypto
      const amountStr = amount.toString()

      // Realizar el pago
      const success = await payWithCrypto(orderId, amountStr)

      if (success) {
        setPaymentStatus("success")

        // Notificar que el pago se completó
        onPaymentComplete()
      } else {
        setPaymentStatus("error")
        setErrorMessage("Error al procesar el pago. Inténtalo de nuevo.")
      }
    } catch (error) {
      console.error("Error en el pago:", error)
      setPaymentStatus("error")
      setErrorMessage("Error al procesar el pago. Inténtalo de nuevo.")
    }
  }

  // Función para conectar la billetera
  const handleConnectWallet = async () => {
    if (!walletDetected) {
      setErrorMessage("Por favor instala MetaMask para continuar")
      return
    }

    try {
      setErrorMessage("")
      const address = await connectWallet()
      setWalletAddress(address)

      if (address) {
        const rewards = await getPendingRewards(address)
        setPendingRewards(rewards)
      } else {
        setErrorMessage("No se pudo conectar la billetera")
      }
    } catch (error) {
      console.error("Error al conectar billetera:", error)
      setErrorMessage("Error al conectar la billetera")
    }
  }

  // Función para desconectar la billetera
  const handleDisconnectWallet = async () => {
    try {
      await disconnectWallet()
      setWalletAddress(null)
      setPendingRewards("0")
    } catch (error) {
      console.error("Error al desconectar billetera:", error)
      setErrorMessage("Error al desconectar la billetera")
    }
  }

  // Función para simular un pago exitoso (solo para demostración)
  const handleSimulatePayment = () => {
    setPaymentStatus("processing")

    // Simular un tiempo de procesamiento
    setTimeout(() => {
      setPaymentStatus("success")
      onPaymentComplete()
    }, 2000)
  }

  // Formatear la dirección de la wallet para mostrarla
  const formatAddress = (address: string) => {
    if (!address) return ""
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  return (
    <Card className="w-full border-2 border-orange-200">
      <CardHeader>
        <CardTitle className="text-xl text-orange-800 flex justify-between items-center">
          <span>Pago con Criptomonedas</span>
          {walletAddress && (
            <span className="text-sm font-normal bg-orange-100 px-2 py-1 rounded-full">
              {formatAddress(walletAddress)}
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center space-y-4">
        {paymentStatus === "success" ? (
          <div className="flex flex-col items-center space-y-3">
            <CheckCircle className="h-16 w-16 text-green-500" />
            <p className="text-green-700 font-medium">¡Pago completado con éxito!</p>
          </div>
        ) : (
          <>
            <div className="bg-white p-4 rounded-lg shadow-md">
              <QRCodeSVG value={qrData} size={180} level="H" includeMargin={true} />
            </div>
            <p className="text-center text-gray-600 text-sm">
              Escanea este código QR con tu aplicación de billetera para pagar con tus criptomonedas.
            </p>

            <div className="w-full bg-orange-50 p-3 rounded-lg border border-orange-200">
              <div className="flex justify-between items-center">
                <span className="text-orange-800 font-medium">Monto a pagar:</span>
                <span className="font-bold">{formatPrice(amount)}</span>
              </div>
              {walletAddress && (
                <div className="flex justify-between items-center mt-2">
                  <span className="text-orange-800 font-medium">Saldo disponible:</span>
                  <span className="font-bold">{formatPrice(Number.parseFloat(pendingRewards))}</span>
                </div>
              )}
            </div>

            {!walletAddress ? (
              <Button
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
                onClick={handleConnectWallet}
                disabled={!walletDetected}
              >
                <Wallet className="mr-2 h-4 w-4" />
                {walletDetected ? "Conectar Billetera" : "MetaMask no detectado"}
              </Button>
            ) : (
              <div className="w-full space-y-3">
                <Button
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white"
                  onClick={handleProcessPayment}
                  disabled={paymentStatus === "processing"}
                >
                  {paymentStatus === "processing" ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Procesando...
                    </>
                  ) : (
                    "Pagar con Criptomonedas"
                  )}
                </Button>

                <Button
                  variant="outline"
                  className="w-full border-orange-300 text-orange-800"
                  onClick={handleDisconnectWallet}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Desconectar Billetera
                </Button>
              </div>
            )}

            {/* Botón para simular pago (solo para demostración) */}
            <Button
              variant="outline"
              className="w-full border-orange-300 text-orange-800 hover:bg-orange-50"
              onClick={handleSimulatePayment}
              disabled={paymentStatus === "processing"}
            >
              Simular Pago Exitoso (Demo)
            </Button>

            {errorMessage && (
              <div className="flex items-center text-red-600 text-sm">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errorMessage}
              </div>
            )}

            {!walletDetected && (
              <div className="text-center text-amber-600 text-sm p-3 bg-amber-50 border border-amber-200 rounded-lg w-full">
                <p>Para utilizar esta función, necesitas instalar la extensión MetaMask en tu navegador.</p>
                <a
                  href="https://metamask.io/download/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline font-medium mt-1 inline-block"
                >
                  Descargar MetaMask
                </a>
              </div>
            )}
          </>
        )}
      </CardContent>
      <CardFooter className="text-xs text-gray-500 text-center">
        <p>
          Los pagos se procesan a través del contrato de criptomonedas. Asegúrate de tener suficientes tokens en tu
          billetera.
        </p>
      </CardFooter>
    </Card>
  )
}
