"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Globe } from "lucide-react"
import { useCurrency, countries } from "@/lib/currency-context"

export function CountrySelector() {
  const { country, setCountry } = useCurrency()
  const [isOpen, setIsOpen] = useState(false)

  const handleSelectCountry = (newCountry: typeof country) => {
    setCountry(newCountry)
    setIsOpen(false)
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 border-orange-200 text-orange-800">
          <Globe className="h-4 w-4" />
          <span className="mr-1">{country.flag}</span>
          <span className="hidden sm:inline">{country.name}</span>
          <span className="text-xs bg-orange-100 px-1.5 py-0.5 rounded-full">{country.currency.code}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[200px]">
        {countries.map((c) => (
          <DropdownMenuItem
            key={c.code}
            className={`flex items-center gap-2 cursor-pointer ${c.code === country.code ? "bg-orange-100" : ""}`}
            onClick={() => handleSelectCountry(c)}
          >
            <span className="text-lg">{c.flag}</span>
            <div className="flex flex-col">
              <span>{c.name}</span>
              <span className="text-xs text-gray-500">
                {c.currency.name} ({c.currency.symbol})
              </span>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
