"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, AlertCircle, CheckCircle, QrCode, Copy } from "lucide-react"
import { useCurrency } from "@/lib/currency-context"
import { QRCodeSVG } from "qrcode.react"
import { toast } from "@/components/ui/use-toast"

interface FiatToCryptoPaymentProps {
  orderId: string
  amount: number
  onPaymentComplete: () => void
}

export function FiatToCryptoPayment({ orderId, amount, onPaymentComplete }: FiatToCryptoPaymentProps) {
  const { formatPrice, country } = useCurrency()
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "processing" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState<string>("")

  // Wallet de destino especificada por el usuario
  const destinationWallet = "0xd41b7e8050d26cbd01490d8d9e1781f48ad8ab52"

  // Tasas de conversión simuladas (en la vida real, estas vendrían de una API)
  const conversionRates = {
    USD: {
      BTC: 0.000026,
      ETH: 0.00041,
      USDT: 1.0,
    },
    MXN: {
      BTC: 0.0000015,
      ETH: 0.000024,
      USDT: 0.059,
    },
  }

  // Criptomoneda seleccionada para recibir
  const [receiveCrypto, setReceiveCrypto] = useState<"BTC" | "ETH" | "USDT">("USDT")

  // Calcular cuánta criptomoneda recibirá el comerciante
  const calculateCryptoAmount = () => {
    const currencyCode = country.currency.code as keyof typeof conversionRates
    const rate = conversionRates[currencyCode]?.[receiveCrypto] || conversionRates.USD[receiveCrypto] * 0.059 // Fallback usando tasa USD convertida

    return (amount * rate).toFixed(receiveCrypto === "USDT" ? 2 : 6)
  }

  // Generar datos para el código QR de pago
  const generateQRData = () => {
    // En un caso real, esto generaría un enlace a un sistema de pago como CoDi o SPEI
    return JSON.stringify({
      concept: `Pago Orden #${orderId}`,
      amount: amount,
      currency: country.currency.code,
      reference: `REF-${orderId}`,
      merchant: "TESH TAP-INFO PAY",
      destinationWallet: destinationWallet,
      cryptoCurrency: receiveCrypto,
      cryptoAmount: calculateCryptoAmount(),
      timestamp: Date.now(),
    })
  }

  // Función para copiar la dirección de wallet al portapapeles
  const copyWalletAddress = () => {
    navigator.clipboard.writeText(destinationWallet)
    toast({
      title: "Dirección copiada",
      description: "La dirección de wallet ha sido copiada al portapapeles.",
    })
  }

  // Formatear la dirección de wallet para mostrarla
  const formatWalletAddress = (address: string) => {
    if (!address) return ""
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  // Simular verificación de pago
  const checkPaymentStatus = async () => {
    setPaymentStatus("processing")
    setErrorMessage("")

    try {
      // Simular una llamada a API para verificar el estado del pago
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simulamos un 90% de éxito
      if (Math.random() > 0.1) {
        setPaymentStatus("success")
        setTimeout(() => {
          onPaymentComplete()
        }, 1500)
      } else {
        setPaymentStatus("error")
        setErrorMessage("No se ha detectado el pago. Por favor, intenta nuevamente.")
      }
    } catch (error) {
      console.error("Error al verificar el pago:", error)
      setPaymentStatus("error")
      setErrorMessage("Error al verificar el pago. Por favor, intenta nuevamente.")
    }
  }

  // Simular un pago exitoso (solo para demostración)
  const handleSimulatePayment = () => {
    setPaymentStatus("processing")

    // Simular un tiempo de procesamiento
    setTimeout(() => {
      setPaymentStatus("success")
      setTimeout(() => {
        onPaymentComplete()
      }, 1500)
    }, 2000)
  }

  // Si el pago ya fue exitoso, mostrar mensaje de éxito
  if (paymentStatus === "success") {
    return (
      <Card className="w-full border-2 border-green-200">
        <CardContent className="pt-6 flex flex-col items-center text-center">
          <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
          <h3 className="text-xl font-medium text-green-800 mb-2">¡Pago Exitoso!</h3>
          <p className="text-gray-600 mb-4">
            Tu pago ha sido procesado correctamente. Se han enviado {calculateCryptoAmount()} {receiveCrypto} a tu
            wallet.
          </p>
          <div className="bg-green-50 w-full p-3 rounded-lg border border-green-200 text-sm">
            <p className="font-medium text-green-800">Detalles de la transacción:</p>
            <p>Orden: #{orderId}</p>
            <p>Monto pagado: {formatPrice(amount)}</p>
            <p>
              Monto recibido: {calculateCryptoAmount()} {receiveCrypto}
            </p>
            <div className="mt-2 pt-2 border-t border-green-200">
              <p className="font-medium text-green-800">Wallet de destino:</p>
              <p className="font-mono text-xs break-all">{destinationWallet}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full border-2 border-orange-200">
      <CardHeader>
        <CardTitle className="text-xl text-orange-800">Pago con QR en {country.currency.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
            <div className="flex justify-between items-center">
              <span className="text-orange-800 font-medium">Monto a pagar:</span>
              <span className="font-bold">{formatPrice(amount)}</span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-orange-800 font-medium">Recibirás:</span>
              <span className="font-bold">
                {calculateCryptoAmount()} {receiveCrypto}
              </span>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-medium">Selecciona la criptomoneda que deseas recibir:</label>
            <Select value={receiveCrypto} onValueChange={(value: "BTC" | "ETH" | "USDT") => setReceiveCrypto(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una criptomoneda" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                <SelectItem value="USDT">Tether (USDT)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Wallet de destino */}
          <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
            <div className="flex justify-between items-center">
              <span className="text-blue-800 font-medium">Wallet de destino:</span>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 px-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100"
                onClick={copyWalletAddress}
              >
                <Copy className="h-3.5 w-3.5 mr-1" />
                Copiar
              </Button>
            </div>
            <p className="font-mono text-xs mt-1 break-all">{destinationWallet}</p>
          </div>

          <div className="flex flex-col items-center space-y-4">
            <div className="bg-white p-4 rounded-lg shadow-md">
              <QRCodeSVG value={generateQRData()} size={200} level="H" includeMargin={true} />
            </div>

            <div className="text-center text-sm text-gray-600">
              <p className="font-medium mb-1">Instrucciones:</p>
              <ol className="space-y-1 text-left list-decimal pl-5">
                <li>Escanea este código QR con tu aplicación bancaria</li>
                <li>Verifica que el monto sea {formatPrice(amount)}</li>
                <li>Confirma y realiza el pago</li>
                <li>Los fondos se convertirán a {receiveCrypto} y se enviarán a tu wallet</li>
                <li>Una vez completado, haz clic en "Verificar Pago"</li>
              </ol>
            </div>
          </div>

          {errorMessage && (
            <div className="flex items-center text-red-600 text-sm bg-red-50 p-3 rounded-lg border border-red-200">
              <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex flex-col space-y-3">
        <Button
          className="w-full bg-orange-600 hover:bg-orange-700 text-white"
          onClick={checkPaymentStatus}
          disabled={paymentStatus === "processing"}
        >
          {paymentStatus === "processing" ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Verificando...
            </>
          ) : (
            <>
              <QrCode className="mr-2 h-4 w-4" />
              Verificar Pago
            </>
          )}
        </Button>

        {/* Opción para fines de prueba */}
        <div className="w-full text-center">
          <button
            type="button"
            onClick={handleSimulatePayment}
            disabled={paymentStatus === "processing"}
            className="text-xs text-gray-500 hover:text-orange-600 underline mt-2"
          >
            Modo prueba: confirmar sin pago real
          </button>
        </div>
      </CardFooter>
    </Card>
  )
}
