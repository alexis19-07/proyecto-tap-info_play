"use client"

import { useState, useEffect } from "react"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, ChefHat, Truck, Clock } from "lucide-react"

export type OrderStatus = "received" | "preparing" | "ready" | "delivered"

interface OrderStatusTrackerProps {
  status: OrderStatus
  estimatedTime: number
}

export function OrderStatusTracker({ status, estimatedTime }: OrderStatusTrackerProps) {
  const [progress, setProgress] = useState(0)

  // Calcular el progreso basado en el estado
  useEffect(() => {
    switch (status) {
      case "received":
        setProgress(25)
        break
      case "preparing":
        setProgress(50)
        break
      case "ready":
        setProgress(75)
        break
      case "delivered":
        setProgress(100)
        break
      default:
        setProgress(0)
    }
  }, [status])

  const getStatusText = () => {
    switch (status) {
      case "received":
        return "Pedido recibido"
      case "preparing":
        return "Preparando su pedido"
      case "ready":
        return "¡Su pedido está listo!"
      case "delivered":
        return "Pedido entregado"
      default:
        return "Estado desconocido"
    }
  }

  const getStatusDescription = () => {
    switch (status) {
      case "received":
        return "Hemos recibido su pedido y lo estamos procesando."
      case "preparing":
        return "Nuestros chefs están preparando su pedido con los mejores ingredientes."
      case "ready":
        return "Su pedido está listo y será entregado en su mesa en breve."
      case "delivered":
        return "¡Disfrute su comida! Gracias por elegirnos."
      default:
        return ""
    }
  }

  const getStatusIcon = (stepStatus: OrderStatus) => {
    const isActive = getStatusIndex(status) >= getStatusIndex(stepStatus)
    const iconClasses = isActive ? "text-orange-600" : "text-gray-300"
    const bgClasses = isActive ? "bg-orange-100 border-orange-200" : "bg-gray-100 border-gray-200"

    let icon
    switch (stepStatus) {
      case "received":
        icon = <Clock className={`h-6 w-6 ${iconClasses}`} />
        break
      case "preparing":
        icon = <ChefHat className={`h-6 w-6 ${iconClasses}`} />
        break
      case "ready":
        icon = <CheckCircle className={`h-6 w-6 ${iconClasses}`} />
        break
      case "delivered":
        icon = <Truck className={`h-6 w-6 ${iconClasses}`} />
        break
    }

    return <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center ${bgClasses}`}>{icon}</div>
  }

  const getStatusIndex = (statusValue: OrderStatus) => {
    const statusOrder = ["received", "preparing", "ready", "delivered"]
    return statusOrder.indexOf(statusValue)
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium text-lg text-orange-800">{getStatusText()}</h3>
        <p className="text-gray-600">{getStatusDescription()}</p>
      </div>

      <div className="relative">
        <Progress value={progress} className="h-2" />

        <div className="flex justify-between mt-4">
          <div className="flex flex-col items-center">
            {getStatusIcon("received")}
            <span className="text-xs mt-2 text-center">Recibido</span>
          </div>

          <div className="flex flex-col items-center">
            {getStatusIcon("preparing")}
            <span className="text-xs mt-2 text-center">Preparando</span>
          </div>

          <div className="flex flex-col items-center">
            {getStatusIcon("ready")}
            <span className="text-xs mt-2 text-center">Listo</span>
          </div>

          <div className="flex flex-col items-center">
            {getStatusIcon("delivered")}
            <span className="text-xs mt-2 text-center">Entregado</span>
          </div>
        </div>
      </div>
    </div>
  )
}
