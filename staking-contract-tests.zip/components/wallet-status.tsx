"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Wallet, LogOut, Copy, ExternalLink, AlertCircle } from "lucide-react"
import { connectWallet, disconnectWallet, getPendingRewards } from "@/lib/blockchain-service"
import { useCurrency } from "@/lib/currency-context"
import { toast } from "@/components/ui/use-toast"

export function WalletStatus() {
  const { formatPrice } = useCurrency()
  const [walletAddress, setWalletAddress] = useState<string | null>(null)
  const [pendingRewards, setPendingRewards] = useState<string>("0")
  const [isConnecting, setIsConnecting] = useState(false)
  const [walletDetected, setWalletDetected] = useState<boolean>(false)

  // Verificar si MetaMask está instalado
  useEffect(() => {
    const checkWallet = () => {
      if (typeof window !== "undefined" && window.ethereum) {
        setWalletDetected(true)

        // Escuchar cambios de cuenta
        window.ethereum.on("accountsChanged", (accounts: string[]) => {
          if (accounts.length > 0) {
            setWalletAddress(accounts[0])
            updateRewards(accounts[0])
          } else {
            setWalletAddress(null)
            setPendingRewards("0")
          }
        })

        // Escuchar cambios de red
        window.ethereum.on("chainChanged", () => {
          // Recargar la página cuando cambia la red
          window.location.reload()
        })
      }
    }

    checkWallet()

    // Verificar si ya hay una cuenta conectada
    const checkConnectedAccount = async () => {
      if (typeof window !== "undefined" && window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: "eth_accounts" })
          if (accounts.length > 0) {
            setWalletAddress(accounts[0])
            updateRewards(accounts[0])
          }
        } catch (error) {
          console.error("Error al verificar cuenta conectada:", error)
        }
      }
    }

    checkConnectedAccount()

    // Limpiar listeners cuando el componente se desmonta
    return () => {
      if (typeof window !== "undefined" && window.ethereum) {
        window.ethereum.removeAllListeners("accountsChanged")
        window.ethereum.removeAllListeners("chainChanged")
      }
    }
  }, [])

  // Actualizar recompensas para una dirección
  const updateRewards = async (address: string) => {
    try {
      const rewards = await getPendingRewards(address)
      setPendingRewards(rewards)
    } catch (error) {
      console.error("Error al obtener recompensas:", error)
    }
  }

  // Función para conectar la billetera
  const handleConnectWallet = async () => {
    if (!walletDetected) {
      toast({
        title: "MetaMask no detectado",
        description: "Por favor instala la extensión MetaMask para continuar.",
        variant: "destructive",
      })
      return
    }

    setIsConnecting(true)
    try {
      const address = await connectWallet()
      setWalletAddress(address)

      if (address) {
        const rewards = await getPendingRewards(address)
        setPendingRewards(rewards)
        toast({
          title: "Billetera conectada",
          description: "Tu billetera ha sido conectada exitosamente.",
        })
      } else {
        toast({
          title: "Error de conexión",
          description: "No se pudo conectar la billetera.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error al conectar billetera:", error)
      toast({
        title: "Error de conexión",
        description: "Ocurrió un error al conectar la billetera.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  // Función para desconectar la billetera
  const handleDisconnectWallet = async () => {
    try {
      await disconnectWallet()
      setWalletAddress(null)
      setPendingRewards("0")
      toast({
        title: "Billetera desconectada",
        description: "Tu billetera ha sido desconectada exitosamente.",
      })
    } catch (error) {
      console.error("Error al desconectar billetera:", error)
      toast({
        title: "Error",
        description: "Ocurrió un error al desconectar la billetera.",
        variant: "destructive",
      })
    }
  }

  // Función para copiar la dirección al portapapeles
  const copyAddressToClipboard = () => {
    if (walletAddress) {
      navigator.clipboard.writeText(walletAddress)
      toast({
        title: "Dirección copiada",
        description: "La dirección de la billetera ha sido copiada al portapapeles.",
      })
    }
  }

  // Formatear la dirección de la wallet para mostrarla
  const formatAddress = (address: string) => {
    if (!address) return ""
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  // Ver la dirección en el explorador de bloques (simulado)
  const viewInExplorer = () => {
    if (walletAddress) {
      window.open(`https://etherscan.io/address/${walletAddress}`, "_blank")
    }
  }

  if (!walletDetected) {
    return (
      <Button
        variant="outline"
        className="border-orange-300 text-orange-800 hover:bg-orange-100 flex items-center gap-2"
        onClick={() => window.open("https://metamask.io/download/", "_blank")}
      >
        <AlertCircle className="h-4 w-4" />
        <span>Instalar MetaMask</span>
      </Button>
    )
  }

  if (!walletAddress) {
    return (
      <Button
        variant="outline"
        className="border-orange-300 text-orange-800 hover:bg-orange-100 flex items-center gap-2"
        onClick={handleConnectWallet}
        disabled={isConnecting}
      >
        {isConnecting ? (
          <>
            <svg
              className="animate-spin -ml-1 mr-2 h-4 w-4 text-orange-800"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 8.291l2-2.291z"
              ></path>
            </svg>
            Conectando...
          </>
        ) : (
          <>
            <Wallet className="h-4 w-4" />
            <span>Conectar Billetera</span>
          </>
        )}
      </Button>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className="border-orange-300 bg-orange-50 text-orange-800 hover:bg-orange-100 flex items-center gap-2"
        >
          <Wallet className="h-4 w-4" />
          <span>{formatAddress(walletAddress)}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>Mi Billetera</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <div className="px-2 py-2">
          <div className="text-sm font-medium">Saldo disponible:</div>
          <div className="text-lg font-bold text-orange-800">{formatPrice(Number(pendingRewards))}</div>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={copyAddressToClipboard} className="cursor-pointer">
          <Copy className="mr-2 h-4 w-4" />
          <span>Copiar dirección</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={viewInExplorer} className="cursor-pointer">
          <ExternalLink className="mr-2 h-4 w-4" />
          <span>Ver en explorador</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleDisconnectWallet} className="cursor-pointer text-red-600">
          <LogOut className="mr-2 h-4 w-4" />
          <span>Desconectar</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
