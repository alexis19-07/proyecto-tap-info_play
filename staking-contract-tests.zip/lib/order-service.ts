// Tipos
export type OrderStatus = "received" | "preparing" | "ready" | "delivered"

export interface OrderItem {
  id: number
  name: string
  price: number
  quantity: number
}

export interface Order {
  id: string
  items: OrderItem[]
  total: number
  status: OrderStatus
  estimatedTime: number
  tableNumber: number
  paymentMethod: string
  createdAt: Date
}

// Almacenamiento local de órdenes (simulado)
let orders: Order[] = []

// Función para generar un ID único
const generateId = (): string => {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// Función para crear una nueva orden
export const createOrder = async (orderData: {
  items: OrderItem[]
  total: number
  paymentMethod: string
  tableNumber: number
}): Promise<Order> => {
  // Simular una llamada a API
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newOrder: Order = {
    id: generateId(),
    items: orderData.items,
    total: orderData.total,
    status: "received",
    estimatedTime: calculateEstimatedTime(orderData.items),
    tableNumber: orderData.tableNumber,
    paymentMethod: orderData.paymentMethod,
    createdAt: new Date(),
  }

  // Guardar la orden en el almacenamiento local
  orders.push(newOrder)

  // Simular la progresión automática del estado de la orden
  simulateOrderProgress(newOrder.id)

  return newOrder
}

// Función para obtener una orden por ID
export const getOrder = async (orderId: string): Promise<Order | null> => {
  // Simular una llamada a API
  await new Promise((resolve) => setTimeout(resolve, 300))

  const order = orders.find((o) => o.id === orderId)
  return order || null
}

// Función para obtener todas las órdenes
export const getAllOrders = async (): Promise<Order[]> => {
  // Simular una llamada a API
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Si no hay órdenes, crear algunas de ejemplo
  if (orders.length === 0) {
    createSampleOrders()
  }

  return [...orders].sort((a, b) => {
    // Ordenar por fecha de creación (más reciente primero)
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  })
}

// Función para actualizar el estado de una orden
export const updateOrderStatus = async (orderId: string, status: OrderStatus): Promise<Order | null> => {
  // Simular una llamada a API
  await new Promise((resolve) => setTimeout(resolve, 300))

  const orderIndex = orders.findIndex((o) => o.id === orderId)
  if (orderIndex === -1) return null

  orders[orderIndex].status = status

  // Actualizar el tiempo estimado si es necesario
  if (status === "preparing") {
    orders[orderIndex].estimatedTime = Math.max(5, orders[orderIndex].estimatedTime - 2)
  } else if (status === "ready") {
    orders[orderIndex].estimatedTime = 1
  } else if (status === "delivered") {
    orders[orderIndex].estimatedTime = 0
  }

  return orders[orderIndex]
}

// Función para calcular el tiempo estimado de preparación
const calculateEstimatedTime = (items: OrderItem[]): number => {
  // Lógica simple: 5 minutos base + 2 minutos por cada artículo
  const baseTime = 5
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0)
  return baseTime + totalQuantity * 2
}

// Función para simular la progresión automática del estado de una orden
const simulateOrderProgress = (orderId: string): void => {
  const order = orders.find((o) => o.id === orderId)
  if (!order) return

  // Simular cambio a "preparing" después de 10-20 segundos
  setTimeout(
    async () => {
      await updateOrderStatus(orderId, "preparing")

      // Simular cambio a "ready" después de 15-30 segundos
      setTimeout(
        async () => {
          await updateOrderStatus(orderId, "ready")

          // Simular cambio a "delivered" después de 10-20 segundos
          setTimeout(
            async () => {
              await updateOrderStatus(orderId, "delivered")
            },
            10000 + Math.random() * 10000,
          )
        },
        15000 + Math.random() * 15000,
      )
    },
    10000 + Math.random() * 10000,
  )
}

// Función para crear órdenes de ejemplo
const createSampleOrders = (): void => {
  const sampleOrders: Partial<Order>[] = [
    {
      id: "123456",
      items: [
        { id: 1, name: "Guacamole Tradicional", price: 120, quantity: 1 },
        { id: 4, name: "Enchiladas Verdes", price: 180, quantity: 2 },
      ],
      total: 480,
      status: "delivered",
      estimatedTime: 0,
      tableNumber: 5,
      paymentMethod: "card",
      createdAt: new Date(Date.now() - 3600000), // 1 hora atrás
    },
    {
      id: "234567",
      items: [
        { id: 5, name: "Tacos de Arrachera", price: 220, quantity: 1 },
        { id: 10, name: "Agua de Jamaica", price: 45, quantity: 2 },
      ],
      total: 310,
      status: "ready",
      estimatedTime: 1,
      tableNumber: 5,
      paymentMethod: "qr",
      createdAt: new Date(Date.now() - 1800000), // 30 minutos atrás
    },
    {
      id: "345678",
      items: [
        { id: 6, name: "Mole Poblano", price: 210, quantity: 1 },
        { id: 8, name: "Churros con Chocolate", price: 95, quantity: 1 },
      ],
      total: 305,
      status: "preparing",
      estimatedTime: 8,
      tableNumber: 5,
      paymentMethod: "card",
      createdAt: new Date(Date.now() - 600000), // 10 minutos atrás
    },
  ]

  orders = sampleOrders as Order[]
}
