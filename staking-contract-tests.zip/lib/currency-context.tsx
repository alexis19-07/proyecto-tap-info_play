"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Definir los tipos de monedas y países/idiomas disponibles
export type Currency = {
  code: string
  symbol: string
  name: string
  exchangeRate: number // Tasa de cambio con respecto al MXN (base)
}

export type Country = {
  code: string
  name: string
  flag: string
  language: string
  currency: Currency
}

// Lista de países con sus monedas
export const countries: Country[] = [
  {
    code: "MX",
    name: "México",
    flag: "🇲🇽",
    language: "es-MX",
    currency: {
      code: "MXN",
      symbol: "$",
      name: "Peso Mexicano",
      exchangeRate: 1, // Base
    },
  },
  {
    code: "US",
    name: "Estados Unidos",
    flag: "🇺🇸",
    language: "en-US",
    currency: {
      code: "USD",
      symbol: "$",
      name: "Dólar Estadounidense",
      exchangeRate: 0.059, // 1 MXN = 0.059 USD
    },
  },
  {
    code: "CO",
    name: "Colombia",
    flag: "🇨🇴",
    language: "es-CO",
    currency: {
      code: "COP",
      symbol: "$",
      name: "Peso Colombiano",
      exchangeRate: 236.5, // 1 MXN = 236.5 COP
    },
  },
  {
    code: "VE",
    name: "Venezuela",
    flag: "🇻🇪",
    language: "es-VE",
    currency: {
      code: "VES",
      symbol: "Bs.",
      name: "Bolívar Soberano",
      exchangeRate: 2.13, // 1 MXN = 2.13 VES
    },
  },
  {
    code: "ES",
    name: "España",
    flag: "🇪🇸",
    language: "es-ES",
    currency: {
      code: "EUR",
      symbol: "€",
      name: "Euro",
      exchangeRate: 0.054, // 1 MXN = 0.054 EUR
    },
  },
  {
    code: "AR",
    name: "Argentina",
    flag: "🇦🇷",
    language: "es-AR",
    currency: {
      code: "ARS",
      symbol: "$",
      name: "Peso Argentino",
      exchangeRate: 51.8, // 1 MXN = 51.8 ARS
    },
  },
]

// Textos traducidos para la interfaz
export const translations: Record<string, Record<string, string>> = {
  "es-MX": {
    welcome: "Bienvenido",
    menu: "Menú",
    checkout: "Pagar",
    orderStatus: "Estado del Pedido",
    total: "Total",
    pay: "Pagar",
    orderReceived: "Pedido Recibido",
    preparing: "Preparando",
    ready: "Listo",
    delivered: "Entregado",
  },
  "en-US": {
    welcome: "Welcome",
    menu: "Menu",
    checkout: "Checkout",
    orderStatus: "Order Status",
    total: "Total",
    pay: "Pay",
    orderReceived: "Order Received",
    preparing: "Preparing",
    ready: "Ready",
    delivered: "Delivered",
  },
  "es-CO": {
    welcome: "Bienvenido",
    menu: "Menú",
    checkout: "Pagar",
    orderStatus: "Estado del Pedido",
    total: "Total",
    pay: "Pagar",
    orderReceived: "Pedido Recibido",
    preparing: "Preparando",
    ready: "Listo",
    delivered: "Entregado",
  },
  "es-VE": {
    welcome: "Bienvenido",
    menu: "Menú",
    checkout: "Pagar",
    orderStatus: "Estado del Pedido",
    total: "Total",
    pay: "Pagar",
    orderReceived: "Pedido Recibido",
    preparing: "Preparando",
    ready: "Listo",
    delivered: "Entregado",
  },
  "es-ES": {
    welcome: "Bienvenido",
    menu: "Menú",
    checkout: "Pagar",
    orderStatus: "Estado del Pedido",
    total: "Total",
    pay: "Pagar",
    orderReceived: "Pedido Recibido",
    preparing: "Preparando",
    ready: "Listo",
    delivered: "Entregado",
  },
  "es-AR": {
    welcome: "Bienvenido",
    menu: "Menú",
    checkout: "Pagar",
    orderStatus: "Estado del Pedido",
    total: "Total",
    pay: "Pagar",
    orderReceived: "Pedido Recibido",
    preparing: "Preparando",
    ready: "Listo",
    delivered: "Entregado",
  },
}

// Crear el contexto
type CurrencyContextType = {
  country: Country
  setCountry: (country: Country) => void
  formatPrice: (price: number) => string
  convertPrice: (price: number) => number
  t: (key: string) => string
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined)

// Proveedor del contexto
export function CurrencyProvider({ children }: { children: ReactNode }) {
  // Estado para el país/moneda seleccionado
  const [country, setCountry] = useState<Country>(countries[0])

  // Detectar el país del usuario basado en el navegador al cargar
  useEffect(() => {
    if (typeof window !== "undefined") {
      // Intentar obtener el país guardado en localStorage
      const savedCountry = localStorage.getItem("selectedCountry")
      if (savedCountry) {
        const parsedCountry = JSON.parse(savedCountry)
        setCountry(parsedCountry)
        return
      }

      // Si no hay país guardado, intentar detectar por el idioma del navegador
      const userLanguage = navigator.language
      const detectedCountry = countries.find((c) => c.language === userLanguage)
      if (detectedCountry) {
        setCountry(detectedCountry)
      }
    }
  }, [])

  // Guardar el país seleccionado en localStorage cuando cambie
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("selectedCountry", JSON.stringify(country))
    }
  }, [country])

  // Función para formatear precios según la moneda seleccionada
  const formatPrice = (price: number): string => {
    const convertedPrice = convertPrice(price)

    // Formatear según la moneda
    return new Intl.NumberFormat(country.language, {
      style: "currency",
      currency: country.currency.code,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(convertedPrice)
  }

  // Función para convertir precios de MXN a la moneda seleccionada
  const convertPrice = (price: number): number => {
    return price * country.currency.exchangeRate
  }

  // Función para obtener traducciones
  const t = (key: string): string => {
    return translations[country.language]?.[key] || key
  }

  return (
    <CurrencyContext.Provider value={{ country, setCountry, formatPrice, convertPrice, t }}>
      {children}
    </CurrencyContext.Provider>
  )
}

// Hook personalizado para usar el contexto
export function useCurrency() {
  const context = useContext(CurrencyContext)
  if (context === undefined) {
    throw new Error("useCurrency debe ser usado dentro de un CurrencyProvider")
  }
  return context
}
