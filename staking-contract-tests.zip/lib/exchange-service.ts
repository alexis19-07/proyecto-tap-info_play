// Tipos para el servicio de intercambio
export type CryptoCurrency = "BTC" | "ETH" | "USDT" | "BNB" | "SOL"
export type FiatCurrency = "USD" | "EUR" | "MXN" | "COP" | "VES" | "ARS"

// Interfaz para las tasas de cambio
export interface ExchangeRates {
  [fiatCurrency: string]: {
    [cryptoCurrency: string]: number
  }
}

// Tasas de cambio simuladas (en un caso real, estas vendrían de una API)
const mockExchangeRates: ExchangeRates = {
  USD: {
    BTC: 0.000026,
    ETH: 0.00041,
    USDT: 1.0,
    BNB: 0.0033,
    SOL: 0.0125,
  },
  EUR: {
    BTC: 0.000028,
    ETH: 0.00044,
    USDT: 1.08,
    BNB: 0.0036,
    SOL: 0.0135,
  },
  MXN: {
    BTC: 0.0000015,
    ETH: 0.000024,
    USDT: 0.059,
    BNB: 0.00019,
    SOL: 0.00074,
  },
  COP: {
    BTC: 0.0000000063,
    ETH: 0.0000001,
    USDT: 0.00025,
    BNB: 0.0000008,
    SOL: 0.0000031,
  },
  VES: {
    BTC: 0.0000012,
    ETH: 0.000019,
    USDT: 0.047,
    BNB: 0.00015,
    SOL: 0.00059,
  },
  ARS: {
    BTC: 0.00000003,
    ETH: 0.0000005,
    USDT: 0.0012,
    BNB: 0.000004,
    SOL: 0.000015,
  },
}

/**
 * Obtiene la tasa de cambio entre una moneda fiat y una criptomoneda
 * @param fiatCurrency Moneda fiat (USD, EUR, etc.)
 * @param cryptoCurrency Criptomoneda (BTC, ETH, etc.)
 * @returns Tasa de cambio (cuánta criptomoneda se obtiene por 1 unidad de moneda fiat)
 */
export const getExchangeRate = (fiatCurrency: FiatCurrency, cryptoCurrency: CryptoCurrency): number => {
  // En un caso real, esto haría una llamada a una API externa
  if (mockExchangeRates[fiatCurrency] && mockExchangeRates[fiatCurrency][cryptoCurrency]) {
    return mockExchangeRates[fiatCurrency][cryptoCurrency]
  }

  // Si no se encuentra la tasa, devolver un valor por defecto
  return 0
}

/**
 * Convierte un monto en moneda fiat a criptomoneda
 * @param amount Monto en moneda fiat
 * @param fiatCurrency Moneda fiat (USD, EUR, etc.)
 * @param cryptoCurrency Criptomoneda (BTC, ETH, etc.)
 * @returns Monto equivalente en criptomoneda
 */
export const convertFiatToCrypto = (
  amount: number,
  fiatCurrency: FiatCurrency,
  cryptoCurrency: CryptoCurrency,
): number => {
  const rate = getExchangeRate(fiatCurrency, cryptoCurrency)
  return amount * rate
}

/**
 * Convierte un monto en criptomoneda a moneda fiat
 * @param amount Monto en criptomoneda
 * @param cryptoCurrency Criptomoneda (BTC, ETH, etc.)
 * @param fiatCurrency Moneda fiat (USD, EUR, etc.)
 * @returns Monto equivalente en moneda fiat
 */
export const convertCryptoToFiat = (
  amount: number,
  cryptoCurrency: CryptoCurrency,
  fiatCurrency: FiatCurrency,
): number => {
  const rate = getExchangeRate(fiatCurrency, cryptoCurrency)
  if (rate === 0) return 0
  return amount / rate
}

/**
 * Simula un proceso de pago fiat a cripto
 * @param orderId ID de la orden
 * @param amount Monto en moneda fiat
 * @param fiatCurrency Moneda fiat (USD, EUR, etc.)
 * @param cryptoCurrency Criptomoneda a recibir (BTC, ETH, etc.)
 * @param walletAddress Dirección de la wallet donde recibir la criptomoneda
 * @returns Objeto con información de la transacción
 */
export const processFiatToCryptoPayment = async (
  orderId: string,
  amount: number,
  fiatCurrency: FiatCurrency,
  cryptoCurrency: CryptoCurrency,
  walletAddress: string,
): Promise<{
  success: boolean
  transactionId?: string
  cryptoAmount?: number
  error?: string
}> => {
  // Simular un tiempo de procesamiento
  await new Promise((resolve) => setTimeout(resolve, 2000))

  try {
    // Convertir el monto de fiat a cripto
    const cryptoAmount = convertFiatToCrypto(amount, fiatCurrency, cryptoCurrency)

    // Simular una transacción exitosa (90% de probabilidad)
    if (Math.random() > 0.1) {
      return {
        success: true,
        transactionId: `tx_${Date.now().toString(36)}`,
        cryptoAmount,
      }
    } else {
      return {
        success: false,
        error: "Error en el procesamiento del pago. Por favor, inténtalo de nuevo.",
      }
    }
  } catch (error) {
    return {
      success: false,
      error: "Error inesperado en el servicio de intercambio.",
    }
  }
}

/**
 * Obtiene todas las criptomonedas disponibles para intercambio
 * @returns Lista de criptomonedas disponibles
 */
export const getAvailableCryptoCurrencies = (): CryptoCurrency[] => {
  return ["BTC", "ETH", "USDT", "BNB", "SOL"]
}

/**
 * Obtiene todas las monedas fiat disponibles para intercambio
 * @returns Lista de monedas fiat disponibles
 */
export const getAvailableFiatCurrencies = (): FiatCurrency[] => {
  return ["USD", "EUR", "MXN", "COP", "VES", "ARS"]
}
