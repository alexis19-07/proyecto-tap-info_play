"use client"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, ArrowRight } from "lucide-react"
import { motion } from "framer-motion"
import { QRCodeSVG } from "qrcode.react"

export default function PaymentSuccess() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId")

  const handleViewOrder = () => {
    router.push(`/order-status?orderId=${orderId}`)
  }

  const handleBackToMenu = () => {
    // Limpiar el carrito
    localStorage.removeItem("cart")
    router.push("/menu")
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="border-2 border-green-200 shadow-lg">
          <CardHeader className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="flex justify-center mb-4"
            >
              <CheckCircle2 className="h-20 w-20 text-green-500" />
            </motion.div>
            <CardTitle className="text-2xl text-green-800">¡Pago Exitoso!</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-gray-600">
              Su pedido ha sido recibido y está siendo procesado. Puede seguir el estado de su pedido con el siguiente
              código QR.
            </p>

            <div className="flex justify-center my-6">
              <div className="bg-white p-4 rounded-lg shadow-md">
                <QRCodeSVG
                  value={`${window.location.origin}/order-status?orderId=${orderId}`}
                  size={180}
                  level="H"
                  includeMargin={true}
                />
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="font-medium text-green-800">Número de Orden: #{orderId}</p>
              <p className="text-sm text-green-600">Mesa: #5</p>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-3">
            <Button className="w-full bg-green-600 hover:bg-green-700 text-white" onClick={handleViewOrder}>
              Ver Estado del Pedido
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="w-full border-green-300 text-green-800 hover:bg-green-50"
              onClick={handleBackToMenu}
            >
              Volver al Menú
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </main>
  )
}
