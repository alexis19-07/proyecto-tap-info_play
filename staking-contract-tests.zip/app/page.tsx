"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { WalletStatus } from "@/components/wallet-status"

export default function Home() {
  const router = useRouter()
  const [isSimulating, setIsSimulating] = useState(false)
  const [simulationComplete, setSimulationComplete] = useState(false)

  const handleSimulateNFC = () => {
    setIsSimulating(true)

    // Simular lectura NFC durante 2 segundos
    setTimeout(() => {
      setSimulationComplete(true)

      // Redirigir a la página de bienvenida después de 1 segundo más
      setTimeout(() => {
        router.push("/welcome")
      }, 1000)
    }, 2000)
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-gradient-to-b from-amber-50 to-orange-100">
      <div className="absolute top-4 right-4">
        <WalletStatus />
      </div>

      <Card className="w-full max-w-md border-2 border-orange-200">
        <CardContent className="flex flex-col items-center justify-center p-6 text-center">
          <h1 className="text-3xl font-bold text-orange-800 mb-6">TESH TAP-INFO PAY</h1>

          <div className="mb-8">
            <img
              src="/placeholder.svg?key=3jmnh"
              alt="Restaurant Logo"
              className="rounded-full border-4 border-orange-300 shadow-lg"
              width={200}
              height={200}
            />
          </div>

          {!isSimulating ? (
            <>
              <p className="text-lg mb-8 text-gray-700">
                Bienvenido a nuestra experiencia digital. Toque el botón para simular la lectura NFC de su mesa.
              </p>
              <Button
                onClick={handleSimulateNFC}
                className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-6 text-xl rounded-full"
              >
                Simular Lectura NFC
              </Button>
            </>
          ) : (
            <div className="flex flex-col items-center">
              {!simulationComplete ? (
                <>
                  <Loader2 className="h-16 w-16 text-orange-600 animate-spin mb-4" />
                  <p className="text-lg text-gray-700">Leyendo información de la mesa...</p>
                </>
              ) : (
                <>
                  <div className="h-16 w-16 bg-green-500 rounded-full flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-10 w-10 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-lg text-gray-700">¡Mesa identificada! Redirigiendo...</p>
                </>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  )
}
