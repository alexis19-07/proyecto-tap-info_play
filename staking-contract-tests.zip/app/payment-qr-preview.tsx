import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { QrCode, Copy } from "lucide-react"

export default function PaymentQRPreview() {
  return (
    <div className="bg-gradient-to-b from-amber-50 to-orange-100 min-h-screen p-8">
      <div className="container mx-auto max-w-md">
        <Card className="w-full border-2 border-orange-200">
          <CardHeader>
            <CardTitle className="text-xl text-orange-800">Pago con QR en Peso Mexicano</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                <div className="flex justify-between items-center">
                  <span className="text-orange-800 font-medium">Monto a pagar:</span>
                  <span className="font-bold">$754.00</span>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-orange-800 font-medium">Recibirás:</span>
                  <span className="font-bold">44.49 USDT</span>
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">Selecciona la criptomoneda que deseas recibir:</label>
                <Select defaultValue="USDT">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona una criptomoneda" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                    <SelectItem value="USDT">Tether (USDT)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Wallet de destino */}
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                <div className="flex justify-between items-center">
                  <span className="text-blue-800 font-medium">Wallet de destino:</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100"
                  >
                    <Copy className="h-3.5 w-3.5 mr-1" />
                    Copiar
                  </Button>
                </div>
                <p className="font-mono text-xs mt-1 break-all">0xd41b7e8050d26cbd01490d8d9e1781f48ad8ab52</p>
              </div>

              <div className="flex flex-col items-center space-y-4">
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <div className="w-[200px] h-[200px] bg-gray-100 flex items-center justify-center">
                    <img src="/qr-code-payment.png" alt="QR Code" width={200} height={200} />
                  </div>
                </div>

                <div className="text-center text-sm text-gray-600">
                  <p className="font-medium mb-1">Instrucciones:</p>
                  <ol className="space-y-1 text-left list-decimal pl-5">
                    <li>Escanea este código QR con tu aplicación bancaria</li>
                    <li>Verifica que el monto sea $754.00</li>
                    <li>Confirma y realiza el pago</li>
                    <li>Los fondos se convertirán a USDT y se enviarán a tu wallet</li>
                    <li>Una vez completado, haz clic en "Verificar Pago"</li>
                  </ol>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-3">
            <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
              <QrCode className="mr-2 h-4 w-4" />
              Verificar Pago
            </Button>

            {/* Opción para fines de prueba */}
            <div className="w-full text-center">
              <button type="button" className="text-xs text-gray-500 hover:text-orange-600 underline mt-2">
                Modo prueba: confirmar sin pago real
              </button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
