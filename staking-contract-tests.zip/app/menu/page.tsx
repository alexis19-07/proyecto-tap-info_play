"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Clock, ArrowRight } from "lucide-react"
import { motion } from "framer-motion"
import { useCurrency } from "@/lib/currency-context"
import { CountrySelector } from "@/components/country-selector"
import { WalletStatus } from "@/components/wallet-status"

// Datos de ejemplo para el menú
const menuData = {
  entradas: [
    {
      id: 1,
      name: "Guacamole Tradicional",
      price: 120,
      description: "Aguacate fresco machacado con cebolla, cilantro, chile y limón",
      image: "guacamole",
    },
    {
      id: 2,
      name: "Queso Fundido",
      price: 150,
      description: "Queso oaxaca derretido con chorizo y chile poblano",
      image: "queso-fundido",
    },
    {
      id: 3,
      name: "Sopa de Tortilla",
      price: 95,
      description: "Caldo de tomate con tortilla crujiente, aguacate y queso",
      image: "sopa-tortilla",
    },
  ],
  principales: [
    {
      id: 4,
      name: "Enchiladas Verdes",
      price: 180,
      description: "Tortillas rellenas de pollo bañadas en salsa verde con crema y queso",
      image: "enchiladas",
    },
    {
      id: 5,
      name: "Tacos de Arrachera",
      price: 220,
      description: "Tres tacos de arrachera con guacamole, cebolla y cilantro",
      image: "tacos-arrachera",
    },
    {
      id: 6,
      name: "Mole Poblano",
      price: 210,
      description: "Pechuga de pollo bañada en mole poblano con arroz y tortillas",
      image: "mole",
    },
  ],
  postres: [
    {
      id: 7,
      name: "Flan Napolitano",
      price: 85,
      description: "Flan casero con caramelo y un toque de vainilla",
      image: "flan",
    },
    {
      id: 8,
      name: "Churros con Chocolate",
      price: 95,
      description: "Churros recién hechos con salsa de chocolate para sumergir",
      image: "churros",
    },
    {
      id: 9,
      name: "Pastel de Tres Leches",
      price: 90,
      description: "Esponjoso pastel bañado en tres tipos de leche",
      image: "tres-leches",
    },
  ],
  bebidas: [
    {
      id: 10,
      name: "Agua de Jamaica",
      price: 45,
      description: "Refrescante agua de flor de jamaica con un toque de limón",
      image: "jamaica",
    },
    {
      id: 11,
      name: "Margarita",
      price: 130,
      description: "Clásica margarita con tequila, limón y sal en el borde",
      image: "margarita",
    },
    {
      id: 12,
      name: "Cerveza Artesanal",
      price: 85,
      description: "Cerveza local artesanal, pregunte por nuestras opciones",
      image: "cerveza",
    },
  ],
}

export default function Menu() {
  const router = useRouter()
  const { formatPrice, t } = useCurrency()
  const [cart, setCart] = useState<{ id: number; name: string; price: number; quantity: number }[]>([])
  const [activeTab, setActiveTab] = useState("entradas")

  const addToCart = (item: { id: number; name: string; price: number }) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((cartItem) => cartItem.id === item.id)

      if (existingItem) {
        return prevCart.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        )
      } else {
        return [...prevCart, { ...item, quantity: 1 }]
      }
    })
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const handleCheckout = () => {
    // Guardar el carrito en localStorage para usarlo en la página de checkout
    localStorage.setItem("cart", JSON.stringify(cart))
    router.push("/checkout")
  }

  const handleViewOrders = () => {
    router.push("/orders")
  }

  const renderMenuItem = (item: { id: number; name: string; price: number; description: string; image: string }) => (
    <motion.div
      key={item.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="mb-4 overflow-hidden hover:shadow-lg transition-shadow">
        <div className="flex flex-col sm:flex-row">
          <div className="w-full sm:w-1/3 h-48 sm:h-auto">
            <img
              src={`/abstract-geometric-shapes.png?height=200&width=200&query=${item.image} mexican food dish`}
              alt={item.name}
              className="w-full h-full object-cover"
            />
          </div>
          <CardContent className="flex-1 p-4">
            <div className="flex justify-between items-start">
              <h3 className="text-xl font-bold text-orange-800">{item.name}</h3>
              <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">
                {formatPrice(item.price)}
              </Badge>
            </div>
            <p className="text-gray-600 mt-2 mb-4">{item.description}</p>
            <Button onClick={() => addToCart(item)} className="bg-orange-600 hover:bg-orange-700 text-white" size="sm">
              Agregar al Pedido
            </Button>
          </CardContent>
        </div>
      </Card>
    </motion.div>
  )

  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 pb-24">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-orange-800">{t("menu")}</h1>
          <div className="flex gap-2">
            <WalletStatus />
            <CountrySelector />
            <Button
              variant="outline"
              className="border-orange-300 text-orange-800 hover:bg-orange-100"
              onClick={handleViewOrders}
            >
              <Clock className="mr-2 h-4 w-4" />
              Ver Pedidos
            </Button>
          </div>
        </div>

        <Tabs defaultValue="entradas" className="mb-8" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="entradas" className={activeTab === "entradas" ? "bg-orange-600 text-white" : ""}>
              Entradas
            </TabsTrigger>
            <TabsTrigger value="principales" className={activeTab === "principales" ? "bg-orange-600 text-white" : ""}>
              Principales
            </TabsTrigger>
            <TabsTrigger value="postres" className={activeTab === "postres" ? "bg-orange-600 text-white" : ""}>
              Postres
            </TabsTrigger>
            <TabsTrigger value="bebidas" className={activeTab === "bebidas" ? "bg-orange-600 text-white" : ""}>
              Bebidas
            </TabsTrigger>
          </TabsList>

          <TabsContent value="entradas">{menuData.entradas.map(renderMenuItem)}</TabsContent>

          <TabsContent value="principales">{menuData.principales.map(renderMenuItem)}</TabsContent>

          <TabsContent value="postres">{menuData.postres.map(renderMenuItem)}</TabsContent>

          <TabsContent value="bebidas">{menuData.bebidas.map(renderMenuItem)}</TabsContent>
        </Tabs>
      </div>

      {/* Carrito flotante en la parte inferior */}
      {getTotalItems() > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t-2 border-orange-200 p-4">
          <div className="container mx-auto">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <ShoppingCart className="text-orange-600 mr-2" />
                <span className="font-medium">
                  {getTotalItems()} {getTotalItems() === 1 ? "artículo" : "artículos"} -
                  <span className="font-bold text-orange-800 ml-1">{formatPrice(getTotalPrice())}</span>
                </span>
              </div>
              <Button onClick={handleCheckout} className="bg-orange-600 hover:bg-orange-700 text-white">
                {t("checkout")}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </main>
  )
}
