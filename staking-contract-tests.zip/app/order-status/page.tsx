"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Clock } from "lucide-react"
import { getOrder } from "@/lib/order-service"
import { OrderStatusTracker } from "@/components/order-status-tracker"

export default function OrderStatus() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId")

  const [order, setOrder] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchOrder = async () => {
      if (!orderId) return

      try {
        const orderData = await getOrder(orderId)
        setOrder(orderData)
      } catch (error) {
        console.error("Error al obtener la orden:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchOrder()

    // Actualizar el estado de la orden cada 10 segundos
    const interval = setInterval(fetchOrder, 10000)

    return () => clearInterval(interval)
  }, [orderId])

  const handleBack = () => {
    router.push("/menu")
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 flex items-center justify-center p-4">
        <div className="text-center">
          <Clock className="h-12 w-12 text-orange-600 animate-pulse mx-auto mb-4" />
          <p className="text-lg text-gray-700">Cargando información del pedido...</p>
        </div>
      </main>
    )
  }

  if (!order) {
    return (
      <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 flex items-center justify-center p-4">
        <Card className="border-2 border-orange-200 w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-lg text-gray-700 mb-4">No se encontró la orden solicitada.</p>
            <Button onClick={handleBack} className="bg-orange-600 hover:bg-orange-700 text-white">
              Volver al Menú
            </Button>
          </CardContent>
        </Card>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 py-8">
      <div className="container mx-auto px-4">
        <Button variant="ghost" className="mb-6 text-orange-800" onClick={handleBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver al Menú
        </Button>

        <div className="max-w-2xl mx-auto">
          <Card className="border-2 border-orange-200 mb-6">
            <CardHeader>
              <CardTitle className="text-2xl text-orange-800">Estado de su Pedido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium text-lg">Orden #{order.id}</p>
                    <p className="text-sm text-gray-500">Mesa #5</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-lg">${order.total.toFixed(2)}</p>
                    <p className="text-sm text-gray-500">{order.items.length} artículos</p>
                  </div>
                </div>

                {/* Componente de seguimiento de estado */}
                <OrderStatusTracker status={order.status} estimatedTime={order.estimatedTime} />

                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <h3 className="font-medium text-orange-800 mb-2">Tiempo estimado de preparación:</h3>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-orange-600 mr-2" />
                    <span className="font-bold text-lg">{order.estimatedTime} minutos</span>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium text-gray-700 mb-3">Artículos en su pedido:</h3>
                  <div className="space-y-2">
                    {order.items.map((item: any) => (
                      <div key={item.id} className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-2 h-2 bg-orange-400 rounded-full mr-2"></div>
                          <span>{item.name}</span>
                        </div>
                        <span className="text-gray-600">x{item.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
