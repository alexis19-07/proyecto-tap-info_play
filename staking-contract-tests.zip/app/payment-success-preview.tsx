import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"

export default function PaymentSuccessPreview() {
  return (
    <div className="bg-gradient-to-b from-amber-50 to-orange-100 min-h-screen p-8">
      <div className="container mx-auto max-w-md">
        <Card className="w-full border-2 border-green-200">
          <CardContent className="pt-6 flex flex-col items-center text-center">
            <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
            <h3 className="text-xl font-medium text-green-800 mb-2">¡Pago Exitoso!</h3>
            <p className="text-gray-600 mb-4">
              Tu pago ha sido procesado correctamente. Se han enviado 44.49 USDT a tu wallet.
            </p>
            <div className="bg-green-50 w-full p-3 rounded-lg border border-green-200 text-sm">
              <p className="font-medium text-green-800">Detalles de la transacción:</p>
              <p>Orden: #123456</p>
              <p>Monto pagado: $754.00</p>
              <p>Monto recibido: 44.49 USDT</p>
              <div className="mt-2 pt-2 border-t border-green-200">
                <p className="font-medium text-green-800">Wallet de destino:</p>
                <p className="font-mono text-xs break-all">0xd41b7e8050d26cbd01490d8d9e1781f48ad8ab52</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
