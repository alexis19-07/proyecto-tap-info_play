"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Wallet, ExternalLink, Copy, Clock, ArrowRightLeft } from "lucide-react"
import { connectWallet, disconnectWallet, getPendingRewards } from "@/lib/blockchain-service"
import { useCurrency } from "@/lib/currency-context"
import { CountrySelector } from "@/components/country-selector"
import { toast } from "@/components/ui/use-toast"

export default function WalletPage() {
  const router = useRouter()
  const { formatPrice } = useCurrency()
  const [walletAddress, setWalletAddress] = useState<string | null>(null)
  const [pendingRewards, setPendingRewards] = useState<string>("0")
  const [isConnecting, setIsConnecting] = useState(false)
  const [walletDetected, setWalletDetected] = useState<boolean>(false)
  const [transactions, setTransactions] = useState<any[]>([])

  // Verificar si MetaMask está instalado
  useEffect(() => {
    const checkWallet = () => {
      if (typeof window !== "undefined" && window.ethereum) {
        setWalletDetected(true)

        // Escuchar cambios de cuenta
        window.ethereum.on("accountsChanged", (accounts: string[]) => {
          if (accounts.length > 0) {
            setWalletAddress(accounts[0])
            updateRewards(accounts[0])
          } else {
            setWalletAddress(null)
            setPendingRewards("0")
          }
        })

        // Escuchar cambios de red
        window.ethereum.on("chainChanged", () => {
          // Recargar la página cuando cambia la red
          window.location.reload()
        })
      }
    }

    checkWallet()

    // Verificar si ya hay una cuenta conectada
    const checkConnectedAccount = async () => {
      if (typeof window !== "undefined" && window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: "eth_accounts" })
          if (accounts.length > 0) {
            setWalletAddress(accounts[0])
            updateRewards(accounts[0])
            loadTransactions(accounts[0])
          }
        } catch (error) {
          console.error("Error al verificar cuenta conectada:", error)
        }
      }
    }

    checkConnectedAccount()

    // Limpiar listeners cuando el componente se desmonta
    return () => {
      if (typeof window !== "undefined" && window.ethereum) {
        window.ethereum.removeAllListeners("accountsChanged")
        window.ethereum.removeAllListeners("chainChanged")
      }
    }
  }, [])

  // Actualizar recompensas para una dirección
  const updateRewards = async (address: string) => {
    try {
      const rewards = await getPendingRewards(address)
      setPendingRewards(rewards)
    } catch (error) {
      console.error("Error al obtener recompensas:", error)
    }
  }

  // Cargar transacciones simuladas
  const loadTransactions = (address: string) => {
    // Simulamos algunas transacciones para demostración
    const mockTransactions = [
      {
        id: "tx1",
        type: "payment",
        amount: 25.5,
        date: new Date(Date.now() - 86400000), // 1 día atrás
        status: "completed",
        description: "Pago por orden #123456",
      },
      {
        id: "tx2",
        type: "reward",
        amount: 10.0,
        date: new Date(Date.now() - 172800000), // 2 días atrás
        status: "completed",
        description: "Recompensa por staking",
      },
      {
        id: "tx3",
        type: "payment",
        amount: 15.75,
        date: new Date(Date.now() - 345600000), // 4 días atrás
        status: "completed",
        description: "Pago por orden #122789",
      },
    ]

    setTransactions(mockTransactions)
  }

  // Función para conectar la billetera
  const handleConnectWallet = async () => {
    if (!walletDetected) {
      toast({
        title: "MetaMask no detectado",
        description: "Por favor instala la extensión MetaMask para continuar.",
        variant: "destructive",
      })
      return
    }

    setIsConnecting(true)
    try {
      const address = await connectWallet()
      setWalletAddress(address)

      if (address) {
        const rewards = await getPendingRewards(address)
        setPendingRewards(rewards)
        loadTransactions(address)
        toast({
          title: "Billetera conectada",
          description: "Tu billetera ha sido conectada exitosamente.",
        })
      } else {
        toast({
          title: "Error de conexión",
          description: "No se pudo conectar la billetera.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error al conectar billetera:", error)
      toast({
        title: "Error de conexión",
        description: "Ocurrió un error al conectar la billetera.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  // Función para desconectar la billetera
  const handleDisconnectWallet = async () => {
    try {
      await disconnectWallet()
      setWalletAddress(null)
      setPendingRewards("0")
      setTransactions([])
      toast({
        title: "Billetera desconectada",
        description: "Tu billetera ha sido desconectada exitosamente.",
      })
    } catch (error) {
      console.error("Error al desconectar billetera:", error)
      toast({
        title: "Error",
        description: "Ocurrió un error al desconectar la billetera.",
        variant: "destructive",
      })
    }
  }

  // Función para copiar la dirección al portapapeles
  const copyAddressToClipboard = () => {
    if (walletAddress) {
      navigator.clipboard.writeText(walletAddress)
      toast({
        title: "Dirección copiada",
        description: "La dirección de la billetera ha sido copiada al portapapeles.",
      })
    }
  }

  // Formatear la dirección de la wallet para mostrarla
  const formatAddress = (address: string) => {
    if (!address) return ""
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  // Ver la dirección en el explorador de bloques (simulado)
  const viewInExplorer = () => {
    if (walletAddress) {
      window.open(`https://etherscan.io/address/${walletAddress}`, "_blank")
    }
  }

  const handleBack = () => {
    router.push("/menu")
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 py-8">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <Button variant="ghost" className="text-orange-800" onClick={handleBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver al Menú
          </Button>
          <CountrySelector />
        </div>

        <div className="max-w-2xl mx-auto">
          <Card className="border-2 border-orange-200 mb-6">
            <CardHeader>
              <CardTitle className="text-2xl text-orange-800">Mi Billetera</CardTitle>
            </CardHeader>
            <CardContent>
              {!walletDetected ? (
                <div className="text-center py-8 space-y-4">
                  <Wallet className="h-16 w-16 text-orange-300 mx-auto" />
                  <h3 className="text-lg font-medium">MetaMask no detectado</h3>
                  <p className="text-gray-600 max-w-md mx-auto">
                    Para utilizar la funcionalidad de billetera, necesitas instalar la extensión MetaMask en tu
                    navegador.
                  </p>
                  <Button
                    className="bg-orange-600 hover:bg-orange-700 text-white"
                    onClick={() => window.open("https://metamask.io/download/", "_blank")}
                  >
                    Instalar MetaMask
                  </Button>
                </div>
              ) : !walletAddress ? (
                <div className="text-center py-8 space-y-4">
                  <Wallet className="h-16 w-16 text-orange-300 mx-auto" />
                  <h3 className="text-lg font-medium">Conecta tu Billetera</h3>
                  <p className="text-gray-600 max-w-md mx-auto">
                    Conecta tu billetera MetaMask para ver tu saldo, historial de transacciones y realizar pagos con
                    criptomonedas.
                  </p>
                  <Button
                    className="bg-orange-600 hover:bg-orange-700 text-white"
                    onClick={handleConnectWallet}
                    disabled={isConnecting}
                  >
                    {isConnecting ? (
                      <>
                        <svg
                          className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                          ></circle>
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 8.291l2-2.291z"
                          ></path>
                        </svg>
                        Conectando...
                      </>
                    ) : (
                      "Conectar Billetera"
                    )}
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Información de la billetera */}
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium text-orange-800">Dirección de la Billetera</h3>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 px-2 border-orange-200"
                          onClick={copyAddressToClipboard}
                        >
                          <Copy className="h-3.5 w-3.5 mr-1" />
                          Copiar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 px-2 border-orange-200"
                          onClick={viewInExplorer}
                        >
                          <ExternalLink className="h-3.5 w-3.5 mr-1" />
                          Ver
                        </Button>
                      </div>
                    </div>
                    <div className="bg-white p-3 rounded border border-orange-100 font-mono text-sm break-all">
                      {walletAddress}
                    </div>
                  </div>

                  {/* Saldo disponible */}
                  <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
                    <h3 className="text-lg font-medium mb-1">Saldo Disponible</h3>
                    <div className="text-3xl font-bold mb-4">{formatPrice(Number(pendingRewards))}</div>
                    <div className="flex justify-between">
                      <span className="text-orange-100">Recompensas por Staking</span>
                      <span className="font-medium">{formatPrice(Number(pendingRewards))}</span>
                    </div>
                  </div>

                  {/* Historial de transacciones */}
                  <div>
                    <h3 className="font-medium text-lg text-orange-800 mb-3">Historial de Transacciones</h3>
                    {transactions.length > 0 ? (
                      <div className="space-y-3">
                        {transactions.map((tx) => (
                          <div
                            key={tx.id}
                            className="bg-white border border-orange-100 rounded-lg p-3 flex justify-between items-center"
                          >
                            <div className="flex items-center">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                                  tx.type === "payment" ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                                }`}
                              >
                                {tx.type === "payment" ? (
                                  <ArrowRightLeft className="h-4 w-4" />
                                ) : (
                                  <Clock className="h-4 w-4" />
                                )}
                              </div>
                              <div>
                                <p className="font-medium">{tx.description}</p>
                                <p className="text-xs text-gray-500">
                                  {tx.date.toLocaleDateString()} - {tx.date.toLocaleTimeString()}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className={`font-medium ${tx.type === "payment" ? "text-red-600" : "text-green-600"}`}>
                                {tx.type === "payment" ? "-" : "+"} {formatPrice(tx.amount)}
                              </p>
                              <p className="text-xs text-gray-500">{tx.status}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 bg-orange-50 rounded-lg border border-orange-200">
                        <p className="text-gray-600">No hay transacciones para mostrar.</p>
                      </div>
                    )}
                  </div>

                  {/* Botón para desconectar */}
                  <div className="pt-4">
                    <Button
                      variant="outline"
                      className="w-full border-orange-300 text-orange-800"
                      onClick={handleDisconnectWallet}
                    >
                      Desconectar Billetera
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
