"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Clock, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"
import { getAllOrders } from "@/lib/order-service"

export default function Orders() {
  const router = useRouter()
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const ordersData = await getAllOrders()
        setOrders(ordersData)
      } catch (error) {
        console.error("Error al obtener las órdenes:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchOrders()
  }, [])

  const handleBack = () => {
    router.push("/menu")
  }

  const handleViewOrder = (orderId: string) => {
    router.push(`/order-status?orderId=${orderId}`)
  }

  const filteredOrders = orders.filter(
    (order) =>
      order.id.toString().includes(searchTerm) ||
      order.items.some((item: any) => item.name.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "received":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            Recibido
          </Badge>
        )
      case "preparing":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            Preparando
          </Badge>
        )
      case "ready":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Listo
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
            Entregado
          </Badge>
        )
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 py-8">
      <div className="container mx-auto px-4">
        <Button variant="ghost" className="mb-6 text-orange-800" onClick={handleBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver al Menú
        </Button>

        <div className="max-w-2xl mx-auto">
          <Card className="border-2 border-orange-200 mb-6">
            <CardHeader>
              <CardTitle className="text-2xl text-orange-800">Mis Pedidos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  placeholder="Buscar por número de orden o platillo..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              {loading ? (
                <div className="text-center py-8">
                  <Clock className="h-8 w-8 text-orange-600 animate-pulse mx-auto mb-4" />
                  <p className="text-gray-700">Cargando pedidos...</p>
                </div>
              ) : filteredOrders.length > 0 ? (
                <div className="space-y-4">
                  {filteredOrders.map((order) => (
                    <motion.div
                      key={order.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card
                        className="hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => handleViewOrder(order.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium">Orden #{order.id}</p>
                              <p className="text-sm text-gray-500 mt-1">
                                {order.items.length} {order.items.length === 1 ? "artículo" : "artículos"} • $
                                {order.total.toFixed(2)}
                              </p>
                              <div className="mt-2 flex flex-wrap gap-1">
                                {order.items.slice(0, 2).map((item: any) => (
                                  <span key={item.id} className="text-xs text-gray-600">
                                    {item.name}
                                    {item.quantity > 1 ? ` (x${item.quantity})` : ""}
                                    {", "}
                                  </span>
                                ))}
                                {order.items.length > 2 && (
                                  <span className="text-xs text-gray-600">y {order.items.length - 2} más</span>
                                )}
                              </div>
                            </div>
                            <div className="flex flex-col items-end">
                              {getStatusBadge(order.status)}
                              <p className="text-xs text-gray-500 mt-2">
                                {order.status === "delivered" ? "Entregado" : `${order.estimatedTime} min`}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 bg-orange-50 rounded-lg border border-orange-200">
                  <p className="text-gray-700">No se encontraron pedidos.</p>
                  {searchTerm && (
                    <Button variant="link" className="text-orange-600 mt-2" onClick={() => setSearchTerm("")}>
                      Limpiar búsqueda
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
