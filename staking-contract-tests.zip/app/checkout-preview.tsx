import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Coins, CreditCard, ArrowLeft } from "lucide-react"

export default function CheckoutPreview() {
  return (
    <div className="bg-gradient-to-b from-amber-50 to-orange-100 min-h-screen p-8">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-6">
          <Button variant="ghost" className="text-orange-800">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver al Menú
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" className="border-orange-300 bg-orange-50 text-orange-800">
              <span>0xd41b...ab52</span>
            </Button>
            <Button variant="outline" className="border-orange-300 text-orange-800">
              🇲🇽 MXN
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Resumen del pedido */}
          <div className="md:col-span-2">
            <Card className="border-2 border-orange-200 mb-6">
              <CardHeader>
                <CardTitle className="text-2xl text-orange-800">Pagar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Guacamole Tradicional</p>
                      <p className="text-sm text-gray-500">$120.00 x 1</p>
                    </div>
                    <p className="font-medium">$120.00</p>
                  </div>

                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Tacos de Arrachera</p>
                      <p className="text-sm text-gray-500">$220.00 x 2</p>
                    </div>
                    <p className="font-medium">$440.00</p>
                  </div>

                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Agua de Jamaica</p>
                      <p className="text-sm text-gray-500">$45.00 x 2</p>
                    </div>
                    <p className="font-medium">$90.00</p>
                  </div>

                  <Separator className="my-4" />

                  <div className="flex justify-between items-center">
                    <p className="font-medium">Subtotal</p>
                    <p className="font-medium">$650.00</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="font-medium">IVA (16%)</p>
                    <p className="font-medium">$104.00</p>
                  </div>
                  <div className="flex justify-between items-center text-lg font-bold text-orange-800">
                    <p>Total</p>
                    <p>$754.00</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Métodos de pago */}
          <div>
            <Card className="border-2 border-orange-200">
              <CardHeader>
                <CardTitle className="text-2xl text-orange-800">Método de Pago</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="fiat-to-crypto">
                  <TabsList className="grid grid-cols-2 mb-4">
                    <TabsTrigger value="crypto" className="flex items-center gap-2">
                      <Coins className="h-4 w-4" />
                      <span>Pago Directo en Cripto</span>
                    </TabsTrigger>
                    <TabsTrigger value="fiat-to-crypto" className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4" />
                      <span>Pago en MXN</span>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="crypto">
                    <div className="text-center py-4">
                      <p className="text-gray-600 mb-4">
                        Pague directamente con sus criptomonedas de forma rápida y segura.
                      </p>
                      <Button className="bg-orange-600 hover:bg-orange-700 text-white">Generar Código de Pago</Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="fiat-to-crypto">
                    <div className="text-center py-4">
                      <p className="text-gray-600 mb-4">Pague en Peso Mexicano y reciba criptomonedas en su wallet.</p>
                      <Button className="bg-orange-600 hover:bg-orange-700 text-white">Continuar al Pago</Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
