"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Coins, CreditCard } from "lucide-react"
import { motion } from "framer-motion"
import { createOrder } from "@/lib/order-service"
import { CryptoPaymentQR } from "@/components/crypto-payment-qr"
import { FiatToCryptoPayment } from "@/components/fiat-to-crypto-payment"
import { useCurrency } from "@/lib/currency-context"
import { CountrySelector } from "@/components/country-selector"
import { WalletStatus } from "@/components/wallet-status"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type CartItem = {
  id: number
  name: string
  price: number
  quantity: number
}

export default function Checkout() {
  const router = useRouter()
  const { formatPrice, t, country } = useCurrency()
  const [cart, setCart] = useState<CartItem[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string>("")
  const [walletDetected, setWalletDetected] = useState<boolean>(false)
  const [paymentMethod, setPaymentMethod] = useState<"crypto" | "fiat-to-crypto">("crypto")

  useEffect(() => {
    // Verificar si MetaMask está instalado
    if (typeof window !== "undefined" && window.ethereum) {
      setWalletDetected(true)
    }

    // Recuperar el carrito del localStorage
    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }
  }, [])

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const handlePayment = async () => {
    setIsProcessing(true)
    setErrorMessage("")

    try {
      // Crear la orden en el sistema
      const order = await createOrder({
        items: cart,
        total: getTotalPrice(),
        paymentMethod: paymentMethod === "crypto" ? "crypto" : "fiat",
        tableNumber: 5, // Número de mesa fijo para este ejemplo
      })

      // Guardar el ID de la orden
      setOrderId(order.id)
      setIsProcessing(false)
    } catch (error) {
      console.error("Error al procesar el pago:", error)
      setIsProcessing(false)
      setErrorMessage("Error al crear la orden. Por favor intente nuevamente.")
    }
  }

  const handlePaymentComplete = () => {
    // Guardar el ID de la orden para seguimiento
    if (orderId) {
      localStorage.setItem("currentOrderId", orderId)

      // Redirigir a la página de confirmación
      router.push(`/payment-success?orderId=${orderId}`)
    }
  }

  const handleBack = () => {
    router.push("/menu")
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 py-8">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <Button variant="ghost" className="text-orange-800" onClick={handleBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver al Menú
          </Button>
          <div className="flex gap-2">
            <WalletStatus />
            <CountrySelector />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Resumen del pedido */}
          <div className="md:col-span-2">
            <Card className="border-2 border-orange-200 mb-6">
              <CardHeader>
                <CardTitle className="text-2xl text-orange-800">{t("checkout")}</CardTitle>
              </CardHeader>
              <CardContent>
                {cart.length > 0 ? (
                  <div className="space-y-4">
                    {cart.map((item) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex justify-between items-center"
                      >
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-gray-500">
                            {formatPrice(item.price)} x {item.quantity}
                          </p>
                        </div>
                        <p className="font-medium">{formatPrice(item.price * item.quantity)}</p>
                      </motion.div>
                    ))}

                    <Separator className="my-4" />

                    <div className="flex justify-between items-center">
                      <p className="font-medium">Subtotal</p>
                      <p className="font-medium">{formatPrice(getTotalPrice())}</p>
                    </div>
                    <div className="flex justify-between items-center">
                      <p className="font-medium">IVA (16%)</p>
                      <p className="font-medium">{formatPrice(getTotalPrice() * 0.16)}</p>
                    </div>
                    <div className="flex justify-between items-center text-lg font-bold text-orange-800">
                      <p>{t("total")}</p>
                      <p>{formatPrice(getTotalPrice() * 1.16)}</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-center text-gray-500">No hay artículos en el carrito</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Métodos de pago */}
          <div>
            {!orderId ? (
              <Card className="border-2 border-orange-200">
                <CardHeader>
                  <CardTitle className="text-2xl text-orange-800">Método de Pago</CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs
                    defaultValue="crypto"
                    onValueChange={(value) => setPaymentMethod(value as "crypto" | "fiat-to-crypto")}
                  >
                    <TabsList className="grid grid-cols-2 mb-4">
                      <TabsTrigger value="crypto" className="flex items-center gap-2">
                        <Coins className="h-4 w-4" />
                        <span>Pago Directo en Cripto</span>
                      </TabsTrigger>
                      <TabsTrigger value="fiat-to-crypto" className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4" />
                        <span>Pago en {country.currency.code}</span>
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="crypto">
                      <div className="text-center py-4">
                        <p className="text-gray-600 mb-4">
                          Pague directamente con sus criptomonedas de forma rápida y segura.
                        </p>

                        {!walletDetected && (
                          <div className="mb-4 text-amber-600 text-sm p-3 bg-amber-50 border border-amber-200 rounded-lg">
                            <p>Para utilizar esta función, necesitas instalar la extensión MetaMask en tu navegador.</p>
                            <a
                              href="https://metamask.io/download/"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="underline font-medium mt-1 inline-block"
                            >
                              Descargar MetaMask
                            </a>
                          </div>
                        )}

                        <Button
                          className="bg-orange-600 hover:bg-orange-700 text-white"
                          onClick={handlePayment}
                          disabled={isProcessing || cart.length === 0}
                        >
                          {isProcessing ? (
                            <>
                              <svg
                                className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                              >
                                <circle
                                  className="opacity-25"
                                  cx="12"
                                  cy="12"
                                  r="10"
                                  stroke="currentColor"
                                  strokeWidth="4"
                                ></circle>
                                <path
                                  className="opacity-75"
                                  fill="currentColor"
                                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 8.291l2-2.291z"
                                ></path>
                              </svg>
                              Procesando...
                            </>
                          ) : (
                            `Generar Código de Pago`
                          )}
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="fiat-to-crypto">
                      <div className="text-center py-4">
                        <p className="text-gray-600 mb-4">
                          Pague en {country.currency.name} y reciba criptomonedas en su wallet.
                        </p>

                        <Button
                          className="bg-orange-600 hover:bg-orange-700 text-white"
                          onClick={handlePayment}
                          disabled={isProcessing || cart.length === 0}
                        >
                          {isProcessing ? (
                            <>
                              <svg
                                className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                              >
                                <circle
                                  className="opacity-25"
                                  cx="12"
                                  cy="12"
                                  r="10"
                                  stroke="currentColor"
                                  strokeWidth="4"
                                ></circle>
                                <path
                                  className="opacity-75"
                                  fill="currentColor"
                                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 8.291l2-2.291z"
                                ></path>
                              </svg>
                              Procesando...
                            </>
                          ) : (
                            `Continuar al Pago`
                          )}
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>

                  {errorMessage && (
                    <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm">
                      {errorMessage}
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card className="border-2 border-orange-200">
                <CardHeader>
                  <CardTitle className="text-2xl text-orange-800">
                    {paymentMethod === "crypto" ? (
                      <div className="flex items-center">
                        <Coins className="mr-2 h-5 w-5" />
                        Pago con Criptomonedas
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <CreditCard className="mr-2 h-5 w-5" />
                        Pago en {country.currency.name}
                      </div>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {paymentMethod === "crypto" ? (
                    <CryptoPaymentQR
                      orderId={orderId}
                      amount={Number.parseFloat((getTotalPrice() * 1.16).toFixed(2))}
                      onPaymentComplete={handlePaymentComplete}
                    />
                  ) : (
                    <FiatToCryptoPayment
                      orderId={orderId}
                      amount={Number.parseFloat((getTotalPrice() * 1.16).toFixed(2))}
                      onPaymentComplete={handlePaymentComplete}
                    />
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
